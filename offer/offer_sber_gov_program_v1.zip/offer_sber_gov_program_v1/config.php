<?php
$lang = 'ru';
$ip = $_SERVER['REMOTE_ADDR'];
$domain = 'https://'.$_SERVER['HTTP_HOST'];
$FacebookPixel = isset($_REQUEST['pixel']) ? $_REQUEST['pixel'] : false;
